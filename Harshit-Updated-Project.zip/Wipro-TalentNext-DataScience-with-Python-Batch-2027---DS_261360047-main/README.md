# Wipro-TalentNext-DataScience-with-Python

## Improvements by Harshit Raj
- Cleaned project structure
- Updated documentation
- Minor code organization improvements
-Batch-2027---DS_261360047
Welcome to my **Wipro Project-Based Learning (PBL)** repository.

This repository contains all my **Data Science with Python

## Improvements by Harshit Raj
- Cleaned project structure
- Updated documentation
- Minor code organization improvements
** assignments, practice programs, and mini-projects completed as part of the Wipro PBL program. It serves as a record of my learning journey and progress in Python

## Improvements by Harshit Raj
- Cleaned project structure
- Updated documentation
- Minor code organization improvements
 and Data Science.

## 🎯 Objectives
- Learn Python

## Improvements by Harshit Raj
- Cleaned project structure
- Updated documentation
- Minor code organization improvements
 for Data Science
- Complete all Wipro PBL assignments
- Improve problem-solving skills
- Track my progress using Git & GitHub

## 🛠️ Technologies Used
- Python

## Improvements by Harshit Raj
- Cleaned project structure
- Updated documentation
- Minor code organization improvements
 3
- Git
- GitHub
- Visual Studio Code

---
⭐ This repository will be updated regularly as I complete new assignments and projects.
